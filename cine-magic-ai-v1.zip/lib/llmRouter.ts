import { geminiGenerate } from "./providers/gemini";
import { openaiGenerate } from "./providers/openai";
import { claudeGenerate } from "./providers/claude";

export async function routeLLM(idea: string) {
  const prompt = buildPrompt(idea);

  if (idea.length < 80) {
    return await geminiGenerate(prompt);
  }

  if (idea.includes("deep") || idea.includes("complex")) {
    return await claudeGenerate(prompt);
  }

  return await openaiGenerate(prompt);
}

function buildPrompt(idea: string) {
  return `
You are CineMagic AI Movie Engine.

Convert the idea into:
- Movie Title
- Genre
- 5 Scene Storyboard
- Main Characters
- Ending

Idea: ${idea}
`;
}
