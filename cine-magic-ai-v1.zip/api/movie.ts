import { routeLLM } from "../lib/llmRouter";

export default async function handler(req: any, res: any) {
  try {
    if (req.method !== "POST") {
      return res.status(405).json({ error: "POST only" });
    }

    const { idea } = req.body;

    if (!idea) {
      return res.status(400).json({ error: "Missing idea" });
    }

    const result = await routeLLM(idea);

    return res.status(200).json({
      success: true,
      result
    });
  } catch (err: any) {
    return res.status(500).json({
      success: false,
      error: err.message
    });
  }
}
